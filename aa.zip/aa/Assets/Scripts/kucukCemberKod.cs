using UnityEngine;

public class kucukCemberKod : MonoBehaviour // Yeni Mono Script yerine bu ismi kullanmal�s�n
{
    Rigidbody2D rigidbody_;
    bool carptiMi = false;

    // GameObject'i d��ar�da tan�mla
    GameObject oyunYoneticisi;

    public int hiz;

    void Start()
    {
        rigidbody_ = GetComponent<Rigidbody2D>();
        // OYUN Y�NET�C�S�N� BURADA BUL VE DE���KENE ATA
        oyunYoneticisi = GameObject.FindGameObjectWithTag("oyunYoneticisi");

        // �NEML�: E�er Tag'i yanl�� yazd�ysan veya sahnede yoksa, bu sat�r hala null d�necektir.
        // oyunYonetici scriptinin ba�l� oldu�u bo� nesneye "oyunYoneticisi" tag'ini verdi�inden emin ol!
    }

    // FixedUpdate, fizik motoru i�in kullan�l�r
    void FixedUpdate()
    {
        if (!carptiMi)
        {
            // Do�ru hareket kodu: Mevcut pozisyona h�z kadar bir vekt�r ekle.
            Vector2 yeniPozisyon = rigidbody_.position + Vector2.up * hiz * Time.deltaTime;
            rigidbody_.MovePosition(yeniPozisyon);

            // Art�k FindGameObjectWithTag burada yok!
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("donenCember"))
        {
            carptiMi = true;
            transform.SetParent(other.transform);
        }

        // e�er kucukcember carp�yorsa oyun bitiyor
        if (other.gameObject.CompareTag("kucukCember"))
        {
            // E�ER OYUN Y�NET�C�S� BULUNAMAZSA BURADA HATA ALIRSIN (Yukar�daki Start() kontrol�n� yap!)
            if (oyunYoneticisi != null)
            {
                oyunYoneticisi.GetComponent<oyunYonetici>().oyunBitti();
            }
            else
            {
                // Hata mesaj� ile kontrol edebiliriz
                Debug.LogError("Oyun Y�neticisi bulunamad�! 'oyunYoneticisi' Tag'ini kontrol et.");
            }
        }
    }
}