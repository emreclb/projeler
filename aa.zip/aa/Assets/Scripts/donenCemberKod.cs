using UnityEngine;

public class donenCemberKod : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public int hiz;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(0, 0, hiz * Time.deltaTime);
    }
}
