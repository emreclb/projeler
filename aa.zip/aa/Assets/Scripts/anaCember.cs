using UnityEngine;

public class anaCember : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject kucukCember;
    public GameObject donenCember;

    void Start()  
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetButtonDown("Fire1"))
        {
            Instantiate(kucukCember, transform.position, transform.rotation);
        }
    }
}
